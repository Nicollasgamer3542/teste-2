package com.brpacks.arkanis.aac.custom.client.renderer;

import com.brpacks.arkanis.aac.custom.entity.laser.LaserEntity;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.mojang.math.Axis;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.entity.EntityRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;
import org.joml.Matrix4f;

public class LaserRenderer extends EntityRenderer<LaserEntity> {

    private static final ResourceLocation LASER_TEXTURE =
            ResourceLocation.withDefaultNamespace("textures/entity/beacon_beam.png");

    public LaserRenderer(EntityRendererProvider.Context context) {
        super(context);
    }

    @Override
    public void render(LaserEntity entity, float entityYaw, float partialTick,
                       PoseStack poseStack, MultiBufferSource bufferSource, int packedLight) {

        poseStack.pushPose();

        float width = entity.getBeamWidth();
        float height = 8.0f;

        poseStack.translate(0, 0, 0);

        VertexConsumer consumer = bufferSource.getBuffer(RenderType.beaconBeam(LASER_TEXTURE, true));
        Matrix4f matrix = poseStack.last().pose();

        float r = 0.5f, g = 0.7f, b = 1.0f, a = 0.8f;

        // Simple quad beam
        consumer.addVertex(matrix, -width, 0, 0).setColor(r, g, b, a).setUv(0, 0).setLight(packedLight);
        consumer.addVertex(matrix, width, 0, 0).setColor(r, g, b, a).setUv(1, 0).setLight(packedLight);
        consumer.addVertex(matrix, width, height, 0).setColor(r, g, b, a).setUv(1, 1).setLight(packedLight);
        consumer.addVertex(matrix, -width, height, 0).setColor(r, g, b, a).setUv(0, 1).setLight(packedLight);

        poseStack.popPose();

        super.render(entity, entityYaw, partialTick, poseStack, bufferSource, packedLight);
    }

    @Override
    public ResourceLocation getTextureLocation(LaserEntity entity) {
        return LASER_TEXTURE;
    }
}
