package com.brpacks.arkanis.aac.custom.command;

import com.brpacks.arkanis.aac.network.ModNetworking;
import com.brpacks.arkanis.aac.network.SkyColorUpdatePacket;
import com.brpacks.arkanis.aac.util.ColorUtils;
import com.mojang.brigadier.arguments.IntegerArgumentType;
import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import net.minecraft.commands.CommandBuildContext;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.network.chat.Component;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.network.PacketDistributor;

public class SetSkyColorCommand extends BaseCommand {

    public SetSkyColorCommand() {
        super("setskycolor", 2);
    }

    @Override
    protected void build(LiteralArgumentBuilder<CommandSourceStack> cmd, CommandBuildContext context) {
        cmd.then(Commands.literal("rgb")
                .then(Commands.argument("r", IntegerArgumentType.integer(0, 255))
                        .then(Commands.argument("g", IntegerArgumentType.integer(0, 255))
                                .then(Commands.argument("b", IntegerArgumentType.integer(0, 255))
                                        .executes(ctx -> {
                                            int r = IntegerArgumentType.getInteger(ctx, "r");
                                            int g = IntegerArgumentType.getInteger(ctx, "g");
                                            int b = IntegerArgumentType.getInteger(ctx, "b");
                                            Vec3 color = ColorUtils.fromRGB(r, g, b);
                                            SkyColorUpdatePacket packet = new SkyColorUpdatePacket(color.x, color.y, color.z);
                                            ModNetworking.CHANNEL.send(packet, PacketDistributor.ALL.noArg());
                                            ctx.getSource().sendSuccess(() -> Component.literal("§aCor do céu alterada para RGB(" + r + "," + g + "," + b + ")"), true);
                                            return 1;
                                        })))));

        cmd.then(Commands.literal("hex")
                .then(Commands.argument("hex", StringArgumentType.word())
                        .executes(ctx -> {
                            String hex = StringArgumentType.getString(ctx, "hex");
                            Vec3 color = ColorUtils.fromHex(hex);
                            SkyColorUpdatePacket packet = new SkyColorUpdatePacket(color.x, color.y, color.z);
                            ModNetworking.CHANNEL.send(packet, PacketDistributor.ALL.noArg());
                            ctx.getSource().sendSuccess(() -> Component.literal("§aCor do céu alterada para #" + hex), true);
                            return 1;
                        })));

        cmd.then(Commands.literal("reset")
                .executes(ctx -> {
                    SkyColorUpdatePacket packet = new SkyColorUpdatePacket(true);
                    ModNetworking.CHANNEL.send(packet, PacketDistributor.ALL.noArg());
                    ctx.getSource().sendSuccess(() -> Component.literal("§aCor do céu resetada."), true);
                    return 1;
                }));
    }
}
