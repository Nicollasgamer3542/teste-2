package com.brpacks.arkanis.aac.registry;

import com.brpacks.arkanis.aac.Aac;
import com.brpacks.arkanis.aac.custom.entity.CustomLightningBolt;
import com.brpacks.arkanis.aac.custom.entity.laser.LaserEntity;
import com.brpacks.arkanis.aac.custom.entity.meteor.MeteorEntity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobCategory;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public class ModEntities {

    public static final DeferredRegister<EntityType<?>> ENTITIES =
            DeferredRegister.create(ForgeRegistries.ENTITY_TYPES, Aac.MOD_ID);

    public static final RegistryObject<EntityType<LaserEntity>> LASER_ENTITY =
            ENTITIES.register("laser_entity", () ->
                    EntityType.Builder.<LaserEntity>of(LaserEntity::new, MobCategory.MISC)
                            .sized(0.5f, 0.5f)
                            .build("laser_entity"));

    public static final RegistryObject<EntityType<MeteorEntity>> METEOR_ENTITY =
            ENTITIES.register("meteor_entity", () ->
                    EntityType.Builder.<MeteorEntity>of(MeteorEntity::new, MobCategory.MISC)
                            .sized(1.5f, 1.5f)
                            .build("meteor_entity"));

    public static final RegistryObject<EntityType<CustomLightningBolt>> CUSTOM_LIGHTNING =
            ENTITIES.register("custom_lightning", () ->
                    EntityType.Builder.<CustomLightningBolt>of(CustomLightningBolt::new, MobCategory.MISC)
                            .sized(0.0f, 0.0f)
                            .build("custom_lightning"));
}
