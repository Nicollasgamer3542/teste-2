package com.brpacks.arkanis.aac.custom.entity;

import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LightningBolt;
import net.minecraft.world.level.Level;

public class CustomLightningBolt extends LightningBolt {

    public CustomLightningBolt(EntityType<? extends LightningBolt> type, Level level) {
        super(type, level);
        this.setVisualOnly(false);
    }
}
