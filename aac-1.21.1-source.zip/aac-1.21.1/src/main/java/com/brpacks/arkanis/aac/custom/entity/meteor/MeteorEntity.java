package com.brpacks.arkanis.aac.custom.entity.meteor;

import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.NbtUtils;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.Level.ExplosionInteraction;
import net.minecraft.world.phys.Vec3;
import software.bernie.geckolib.animatable.GeoEntity;
import software.bernie.geckolib.animatable.instance.AnimatableInstanceCache;
import software.bernie.geckolib.animation.*;
import software.bernie.geckolib.util.GeckoLibUtil;

public class MeteorEntity extends Entity implements GeoEntity {

    private static final EntityDataAccessor<Integer> TARGET_X =
            SynchedEntityData.defineId(MeteorEntity.class, EntityDataSerializers.INT);
    private static final EntityDataAccessor<Integer> TARGET_Y =
            SynchedEntityData.defineId(MeteorEntity.class, EntityDataSerializers.INT);
    private static final EntityDataAccessor<Integer> TARGET_Z =
            SynchedEntityData.defineId(MeteorEntity.class, EntityDataSerializers.INT);

    private static final RawAnimation SPIN_ANIM = RawAnimation.begin().thenLoop("animation.meteor.spin");

    private final AnimatableInstanceCache cache = GeckoLibUtil.createInstanceCache(this);

    private BlockPos targetBlock = BlockPos.ZERO;

    public MeteorEntity(EntityType<? extends MeteorEntity> type, Level level) {
        super(type, level);
        this.noPhysics = true;
    }

    @Override
    protected void defineSynchedData(SynchedEntityData.Builder builder) {
        builder.define(TARGET_X, 0);
        builder.define(TARGET_Y, 0);
        builder.define(TARGET_Z, 0);
    }

    public void setTarget(BlockPos pos) {
        this.targetBlock = pos;
        this.entityData.set(TARGET_X, pos.getX());
        this.entityData.set(TARGET_Y, pos.getY());
        this.entityData.set(TARGET_Z, pos.getZ());
    }

    @Override
    public void tick() {
        super.tick();

        BlockPos target = new BlockPos(
                this.entityData.get(TARGET_X),
                this.entityData.get(TARGET_Y),
                this.entityData.get(TARGET_Z));

        Vec3 toTarget = new Vec3(
                target.getX() - this.getX(),
                target.getY() - this.getY(),
                target.getZ() - this.getZ());

        double dist = toTarget.length();

        if (dist < 2.0) {
            if (!this.level().isClientSide && this.level() instanceof ServerLevel serverLevel) {
                serverLevel.explode(this,
                        this.getX(), this.getY(), this.getZ(),
                        5.0f, ExplosionInteraction.TNT);
            }
            this.discard();
            return;
        }

        Vec3 velocity = toTarget.normalize().scale(Math.min(dist * 0.1, 2.5));
        this.setDeltaMovement(velocity);
        this.move(net.minecraft.world.entity.MoverType.SELF, velocity);

        // Spawn particles
        if (this.level().isClientSide) {
            for (int i = 0; i < 5; i++) {
                this.level().addParticle(ParticleTypes.FLAME,
                        this.getX() + (this.random.nextDouble() - 0.5) * 1.5,
                        this.getY() + (this.random.nextDouble() - 0.5) * 1.5,
                        this.getZ() + (this.random.nextDouble() - 0.5) * 1.5,
                        0, 0, 0);
            }
        }
    }

    @Override
    protected void readAdditionalSaveData(CompoundTag tag) {
        if (tag.contains("TargetPos")) {
            BlockPos pos = NbtUtils.readBlockPos(tag, "TargetPos").orElse(BlockPos.ZERO);
            setTarget(pos);
        }
    }

    @Override
    protected void addAdditionalSaveData(CompoundTag tag) {
        tag.put("TargetPos", NbtUtils.writeBlockPos(targetBlock));
    }

    // GeckoLib 4 implementation
    @Override
    public void registerControllers(AnimatableManager.ControllerRegistrar controllers) {
        controllers.add(new AnimationController<>(this, "spin_controller", 0,
                state -> state.setAndContinue(SPIN_ANIM)));
    }

    @Override
    public AnimatableInstanceCache getAnimatableInstanceCache() {
        return cache;
    }
}
