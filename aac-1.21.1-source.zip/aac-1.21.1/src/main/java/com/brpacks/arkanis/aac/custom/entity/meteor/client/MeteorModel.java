package com.brpacks.arkanis.aac.custom.entity.meteor.client;

import com.brpacks.arkanis.aac.Aac;
import com.brpacks.arkanis.aac.custom.entity.meteor.MeteorEntity;
import net.minecraft.resources.ResourceLocation;
import software.bernie.geckolib.model.GeoModel;

public class MeteorModel extends GeoModel<MeteorEntity> {

    @Override
    public ResourceLocation getModelResource(MeteorEntity animatable) {
        return ResourceLocation.fromNamespaceAndPath(Aac.MOD_ID, "geo/meteor.geo.json");
    }

    @Override
    public ResourceLocation getTextureResource(MeteorEntity animatable) {
        return ResourceLocation.fromNamespaceAndPath(Aac.MOD_ID, "textures/entity/meteor.png");
    }

    @Override
    public ResourceLocation getAnimationResource(MeteorEntity animatable) {
        return ResourceLocation.fromNamespaceAndPath(Aac.MOD_ID, "animations/meteor.animation.json");
    }
}
