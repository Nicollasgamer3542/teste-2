package com.brpacks.arkanis.aac;

import com.brpacks.arkanis.aac.custom.client.renderer.CustomLightningBoltRenderer;
import com.brpacks.arkanis.aac.custom.client.renderer.LaserRenderer;
import com.brpacks.arkanis.aac.custom.entity.meteor.client.MeteorRenderer;
import com.brpacks.arkanis.aac.registry.ModEntities;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.EntityRenderersEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.event.lifecycle.FMLClientSetupEvent;

@Mod.EventBusSubscriber(modid = Aac.MOD_ID, bus = Mod.EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
public class AacClient {

    public static void onClientSetup(FMLClientSetupEvent event) {
        // Client setup logic runs here
    }

    @SubscribeEvent
    public static void onRegisterRenderers(EntityRenderersEvent.RegisterRenderers event) {
        event.registerEntityRenderer(ModEntities.LASER_ENTITY.get(), LaserRenderer::new);
        event.registerEntityRenderer(ModEntities.METEOR_ENTITY.get(), MeteorRenderer::new);
        event.registerEntityRenderer(ModEntities.CUSTOM_LIGHTNING.get(), CustomLightningBoltRenderer::new);
    }
}
