package com.brpacks.arkanis.aac;

import net.minecraft.world.phys.Vec3;

public class Data {
    public static Vec3 skyColor = null;
}
