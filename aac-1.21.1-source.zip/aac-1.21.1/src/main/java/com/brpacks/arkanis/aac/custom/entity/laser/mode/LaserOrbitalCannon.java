package com.brpacks.arkanis.aac.custom.entity.laser.mode;

import com.brpacks.arkanis.aac.custom.entity.laser.LaserEntity;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.level.Level.ExplosionInteraction;
import net.minecraft.world.phys.Vec3;

public class LaserOrbitalCannon implements LaserTickFeature {

    private int tickCounter = 0;
    private static final int DELAY_TICKS = 60;

    @Override
    public void tick(LaserEntity laser) {
        if (laser.level().isClientSide) return;

        tickCounter++;

        Vec3 target = laser.getTargetPos();
        if (target == null) {
            laser.discard();
            return;
        }

        // Move laser downward toward target
        Vec3 current = laser.position();
        Vec3 direction = target.subtract(current).normalize().scale(2.0);
        laser.setDeltaMovement(direction);
        laser.move(net.minecraft.world.entity.MoverType.SELF, laser.getDeltaMovement());

        double distSq = laser.position().distanceToSqr(target);

        if (distSq < 4.0 || tickCounter >= DELAY_TICKS) {
            if (laser.level() instanceof ServerLevel serverLevel) {
                serverLevel.explode(laser, target.x, target.y, target.z,
                        5.0f, ExplosionInteraction.TNT);
            }
            laser.discard();
        }
    }
}
