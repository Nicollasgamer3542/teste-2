package com.brpacks.arkanis.aac;

import com.brpacks.arkanis.aac.network.ModNetworking;
import com.brpacks.arkanis.aac.registry.ModEntities;
import com.brpacks.arkanis.aac.registry.ModMobEffects;
import com.brpacks.arkanis.aac.registry.ModSounds;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;

@Mod(Aac.MOD_ID)
public class Aac {

    public static final String MOD_ID = "aac";

    public Aac(FMLJavaModLoadingContext context) {
        IEventBus modEventBus = context.getModEventBus();

        ModEntities.ENTITIES.register(modEventBus);
        ModSounds.SOUNDS.register(modEventBus);
        ModMobEffects.MOB_EFFECTS.register(modEventBus);

        Config.register(modEventBus);
        ModNetworking.register(modEventBus);

        modEventBus.addListener(AacClient::onClientSetup);
    }
}
