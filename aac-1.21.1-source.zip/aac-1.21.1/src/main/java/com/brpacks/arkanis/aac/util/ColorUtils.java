package com.brpacks.arkanis.aac.util;

import net.minecraft.world.phys.Vec3;

public class ColorUtils {

    public static Vec3 fromRGB(int r, int g, int b) {
        return new Vec3(r / 255.0, g / 255.0, b / 255.0);
    }

    public static Vec3 fromHex(String hex) {
        hex = hex.replace("#", "").replace("0x", "").replace("0X", "");
        if (hex.length() == 6) {
            int r = Integer.parseInt(hex.substring(0, 2), 16);
            int g = Integer.parseInt(hex.substring(2, 4), 16);
            int b = Integer.parseInt(hex.substring(4, 6), 16);
            return fromRGB(r, g, b);
        }
        return new Vec3(0.5, 0.7, 1.0);
    }

    public static int[] toRGB(Vec3 vec) {
        return new int[]{
            (int) (vec.x * 255),
            (int) (vec.y * 255),
            (int) (vec.z * 255)
        };
    }
}
