package com.brpacks.arkanis.aac.custom.event;

import com.brpacks.arkanis.aac.Aac;
import com.brpacks.arkanis.aac.custom.command.*;
import net.minecraftforge.event.RegisterCommandsEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

import java.util.List;

@Mod.EventBusSubscriber(modid = Aac.MOD_ID, bus = Mod.EventBusSubscriber.Bus.FORGE)
public class ModCommand {

    private static final List<ICommand> COMMANDS = List.of(
            new SetSkyColorCommand(),
            new SummonLightning(),
            new SummonMeteor(),
            new TeleportCommand()
    );

    @SubscribeEvent
    public static void onRegisterCommands(RegisterCommandsEvent event) {
        for (ICommand command : COMMANDS) {
            command.register(event.getDispatcher(), event.getBuildContext());
        }
    }
}
