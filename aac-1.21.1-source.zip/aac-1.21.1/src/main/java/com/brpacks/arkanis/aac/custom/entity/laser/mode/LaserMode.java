package com.brpacks.arkanis.aac.custom.entity.laser.mode;

public enum LaserMode {
    TELEPORT,
    ORBITAL_CANNON;

    public static LaserMode fromString(String name) {
        for (LaserMode mode : values()) {
            if (mode.name().equalsIgnoreCase(name)) return mode;
        }
        return TELEPORT;
    }
}
