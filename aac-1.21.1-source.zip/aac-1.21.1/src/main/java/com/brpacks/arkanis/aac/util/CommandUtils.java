package com.brpacks.arkanis.aac.util;

import com.mojang.brigadier.context.CommandContext;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.MutableComponent;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.player.Player;

import java.util.List;
import java.util.UUID;

public class CommandUtils {

    /**
     * Send a formatted chat message to a player.
     * r, g, b are 0-255 color components.
     */
    public static void sendMessage(CommandContext<CommandSourceStack> ctx,
                                   MutableComponent component,
                                   int r, int g, int b,
                                   String extra,
                                   Player player) {
        if (player != null) {
            player.sendSystemMessage(component);
        } else {
            ctx.getSource().sendSuccess(() -> component, false);
        }
    }

    public static UUID getUUID(CommandContext<CommandSourceStack> ctx) {
        try {
            return ctx.getSource().getPlayerOrException().getUUID();
        } catch (Exception e) {
            return null;
        }
    }

    public static List<Integer> parseColorArgs(String key,
                                               CommandContext<CommandSourceStack> ctx) {
        String raw = ctx.getArgument(key, String.class);
        String[] parts = raw.split(",");
        if (parts.length == 3) {
            try {
                return List.of(
                    Integer.parseInt(parts[0].trim()),
                    Integer.parseInt(parts[1].trim()),
                    Integer.parseInt(parts[2].trim())
                );
            } catch (NumberFormatException ignored) {}
        }
        return List.of(128, 179, 255);
    }
}
