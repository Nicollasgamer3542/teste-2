package com.brpacks.arkanis.aac.network;

import com.brpacks.arkanis.aac.Data;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.network.NetworkEvent;

public class SkyColorUpdatePacket {

    private final double r, g, b;
    private final boolean reset;

    public SkyColorUpdatePacket(double r, double g, double b) {
        this.r = r;
        this.g = g;
        this.b = b;
        this.reset = false;
    }

    public SkyColorUpdatePacket(boolean reset) {
        this.r = 0;
        this.g = 0;
        this.b = 0;
        this.reset = reset;
    }

    public void encode(FriendlyByteBuf buf) {
        buf.writeBoolean(reset);
        buf.writeDouble(r);
        buf.writeDouble(g);
        buf.writeDouble(b);
    }

    public static SkyColorUpdatePacket decode(FriendlyByteBuf buf) {
        boolean reset = buf.readBoolean();
        double r = buf.readDouble();
        double g = buf.readDouble();
        double b = buf.readDouble();
        if (reset) return new SkyColorUpdatePacket(true);
        return new SkyColorUpdatePacket(r, g, b);
    }

    public void handle(NetworkEvent.Context ctx) {
        ctx.enqueueWork(() -> {
            if (reset) {
                Data.skyColor = null;
            } else {
                Data.skyColor = new Vec3(r, g, b);
            }
        });
    }
}
