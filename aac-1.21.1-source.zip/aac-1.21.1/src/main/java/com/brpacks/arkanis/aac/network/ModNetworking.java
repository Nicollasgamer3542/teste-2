package com.brpacks.arkanis.aac.network;

import com.brpacks.arkanis.aac.Aac;
import net.minecraft.resources.ResourceLocation;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.network.Channel;
import net.minecraftforge.network.ChannelBuilder;
import net.minecraftforge.network.SimpleChannel;

public class ModNetworking {

    private static final int PROTOCOL_VERSION = 1;
    public static SimpleChannel CHANNEL;

    public static void register(IEventBus modEventBus) {
        CHANNEL = ChannelBuilder
                .named(ResourceLocation.fromNamespaceAndPath(Aac.MOD_ID, "main"))
                .clientAcceptedVersions(Channel.VersionTest.exact(PROTOCOL_VERSION))
                .serverAcceptedVersions(Channel.VersionTest.exact(PROTOCOL_VERSION))
                .networkProtocolVersion(PROTOCOL_VERSION)
                .simpleChannel();

        CHANNEL.messageBuilder(SkyColorUpdatePacket.class)
                .encoder(SkyColorUpdatePacket::encode)
                .decoder(SkyColorUpdatePacket::decode)
                .consumerMainThread(SkyColorUpdatePacket::handle)
                .add();
    }
}
