package com.brpacks.arkanis.aac.custom.entity.laser.mode;

import com.brpacks.arkanis.aac.custom.entity.laser.LaserEntity;
import com.brpacks.arkanis.aac.registry.ModSounds;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.phys.Vec3;

import java.util.UUID;

public class LaserTeleport implements LaserTickFeature {

    private int tickCounter = 0;
    private static final int DELAY_TICKS = 40; // 2 seconds

    @Override
    public void tick(LaserEntity laser) {
        if (laser.level().isClientSide) return;

        tickCounter++;

        // Move laser upward visually
        Vec3 pos = laser.position();
        laser.setDeltaMovement(0, 0.5, 0);
        laser.move(net.minecraft.world.entity.MoverType.SELF, laser.getDeltaMovement());

        if (tickCounter >= DELAY_TICKS) {
            UUID ownerUUID = laser.getOwnerUUID();
            Vec3 dest = laser.getTargetPos();

            if (ownerUUID != null && dest != null && laser.level() instanceof ServerLevel serverLevel) {
                ServerPlayer player = serverLevel.getServer().getPlayerList().getPlayer(ownerUUID);
                if (player != null) {
                    player.teleportTo(serverLevel, dest.x, dest.y, dest.z,
                            player.getYRot(), player.getXRot());
                    serverLevel.playSound(null, dest.x, dest.y, dest.z,
                            ModSounds.LASER_TP.get(), SoundSource.PLAYERS, 1.0f, 1.0f);
                }
            }
            laser.discard();
        }
    }
}
