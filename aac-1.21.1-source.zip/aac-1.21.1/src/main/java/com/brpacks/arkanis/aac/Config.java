package com.brpacks.arkanis.aac;

import net.minecraftforge.common.ForgeConfigSpec;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.fml.ModLoadingContext;
import net.minecraftforge.fml.config.ModConfig;
import net.minecraftforge.fml.event.config.ModConfigEvent;

public class Config {

    public static final ForgeConfigSpec.Builder BUILDER = new ForgeConfigSpec.Builder();
    public static final ForgeConfigSpec SPEC;

    public static final ForgeConfigSpec.BooleanValue ENABLE_JOIN_MESSAGE;
    public static final ForgeConfigSpec.ConfigValue<String> JOIN_MESSAGE;
    public static final ForgeConfigSpec.IntValue METEOR_EXPLOSION_POWER;

    static {
        BUILDER.push("general");
        ENABLE_JOIN_MESSAGE = BUILDER.comment("Enable the join message").define("enableJoinMessage", true);
        JOIN_MESSAGE = BUILDER.comment("Message shown when a player joins").define("joinMessage", "&6[AAC] &fBem-vindo ao servidor!");
        BUILDER.pop();

        BUILDER.push("meteor");
        METEOR_EXPLOSION_POWER = BUILDER.comment("Power of meteor explosion").defineInRange("meteorExplosionPower", 5, 0, 20);
        BUILDER.pop();

        SPEC = BUILDER.build();
    }

    public static void register(IEventBus modEventBus) {
        ModLoadingContext.get().registerConfig(ModConfig.Type.COMMON, SPEC);
        modEventBus.addListener(Config::onLoad);
        modEventBus.addListener(Config::onReload);
    }

    private static void onLoad(final ModConfigEvent.Loading event) {}
    private static void onReload(final ModConfigEvent.Reloading event) {}
}
