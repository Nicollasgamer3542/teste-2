package com.brpacks.arkanis.aac.custom.command;

import com.brpacks.arkanis.aac.custom.entity.CustomLightningBolt;
import com.brpacks.arkanis.aac.registry.ModEntities;
import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import net.minecraft.commands.CommandBuildContext;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.commands.arguments.EntityArgument;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.EntityType;

import java.util.Collection;

public class SummonLightning extends BaseCommand {

    public SummonLightning() {
        super("summonlightning", 2);
    }

    @Override
    protected void build(LiteralArgumentBuilder<CommandSourceStack> cmd, CommandBuildContext context) {
        cmd.then(Commands.argument("targets", EntityArgument.players())
                .executes(ctx -> {
                    Collection<ServerPlayer> players = EntityArgument.getPlayers(ctx, "targets");
                    ServerLevel level = ctx.getSource().getLevel();
                    for (ServerPlayer player : players) {
                        CustomLightningBolt bolt = new CustomLightningBolt(
                                ModEntities.CUSTOM_LIGHTNING.get(), level);
                        BlockPos pos = player.blockPosition();
                        bolt.moveTo(pos.getX(), pos.getY(), pos.getZ());
                        level.addFreshEntity(bolt);
                    }
                    ctx.getSource().sendSuccess(
                            () -> Component.literal("§aRaio invocado em " + players.size() + " jogador(es)."), true);
                    return players.size();
                }));

        cmd.executes(ctx -> {
            ServerLevel level = ctx.getSource().getLevel();
            BlockPos pos = BlockPos.containing(ctx.getSource().getPosition());
            CustomLightningBolt bolt = new CustomLightningBolt(ModEntities.CUSTOM_LIGHTNING.get(), level);
            bolt.moveTo(pos.getX(), pos.getY(), pos.getZ());
            level.addFreshEntity(bolt);
            ctx.getSource().sendSuccess(() -> Component.literal("§aRaio invocado."), true);
            return 1;
        });
    }
}
