package com.brpacks.arkanis.aac.registry;

import com.brpacks.arkanis.aac.Aac;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.sounds.SoundEvent;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public class ModSounds {

    public static final DeferredRegister<SoundEvent> SOUNDS =
            DeferredRegister.create(ForgeRegistries.SOUND_EVENTS, Aac.MOD_ID);

    public static final RegistryObject<SoundEvent> LASER_TP =
            SOUNDS.register("laser_tp", () ->
                    SoundEvent.createVariableRangeEvent(ResourceLocation.fromNamespaceAndPath(Aac.MOD_ID, "laser_tp")));
}
