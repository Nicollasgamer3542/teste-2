package com.brpacks.arkanis.aac.custom.entity.laser;

import com.brpacks.arkanis.aac.custom.entity.laser.mode.*;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;

import java.util.Optional;
import java.util.UUID;

public class LaserEntity extends Entity {

    private static final EntityDataAccessor<String> MODE =
            SynchedEntityData.defineId(LaserEntity.class, EntityDataSerializers.STRING);
    private static final EntityDataAccessor<Float> BEAM_WIDTH =
            SynchedEntityData.defineId(LaserEntity.class, EntityDataSerializers.FLOAT);

    private LaserTickFeature tickFeature;
    private Vec3 targetPos;
    private UUID ownerUUID;

    public LaserEntity(EntityType<? extends LaserEntity> type, Level level) {
        super(type, level);
        this.noPhysics = true;
    }

    @Override
    protected void defineSynchedData(SynchedEntityData.Builder builder) {
        builder.define(MODE, LaserMode.TELEPORT.name());
        builder.define(BEAM_WIDTH, 0.2f);
    }

    public void setMode(LaserMode mode) {
        this.entityData.set(MODE, mode.name());
        switch (mode) {
            case TELEPORT -> this.tickFeature = new LaserTeleport();
            case ORBITAL_CANNON -> this.tickFeature = new LaserOrbitalCannon();
        }
    }

    public LaserMode getMode() {
        return LaserMode.fromString(this.entityData.get(MODE));
    }

    public void setTargetPos(Vec3 pos) {
        this.targetPos = pos;
    }

    public Vec3 getTargetPos() {
        return this.targetPos;
    }

    public void setOwnerUUID(UUID uuid) {
        this.ownerUUID = uuid;
    }

    public UUID getOwnerUUID() {
        return this.ownerUUID;
    }

    public float getBeamWidth() {
        return this.entityData.get(BEAM_WIDTH);
    }

    @Override
    public void tick() {
        super.tick();
        if (tickFeature != null) {
            tickFeature.tick(this);
        }
    }

    @Override
    protected void readAdditionalSaveData(CompoundTag tag) {
        if (tag.contains("Mode")) {
            setMode(LaserMode.fromString(tag.getString("Mode")));
        }
        if (tag.contains("TargetX")) {
            this.targetPos = new Vec3(
                    tag.getDouble("TargetX"),
                    tag.getDouble("TargetY"),
                    tag.getDouble("TargetZ"));
        }
        if (tag.hasUUID("OwnerUUID")) {
            this.ownerUUID = tag.getUUID("OwnerUUID");
        }
    }

    @Override
    protected void addAdditionalSaveData(CompoundTag tag) {
        tag.putString("Mode", getMode().name());
        if (targetPos != null) {
            tag.putDouble("TargetX", targetPos.x);
            tag.putDouble("TargetY", targetPos.y);
            tag.putDouble("TargetZ", targetPos.z);
        }
        if (ownerUUID != null) {
            tag.putUUID("OwnerUUID", ownerUUID);
        }
    }
}
