package com.brpacks.arkanis.aac.custom.entity.laser.mode;

import com.brpacks.arkanis.aac.custom.entity.laser.LaserEntity;

public interface LaserTickFeature {
    void tick(LaserEntity laser);
}
