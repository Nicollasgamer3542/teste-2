package com.brpacks.arkanis.aac.custom.entity.meteor.client;

import com.brpacks.arkanis.aac.Aac;
import com.brpacks.arkanis.aac.custom.entity.meteor.MeteorEntity;
import com.mojang.blaze3d.vertex.PoseStack;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.resources.ResourceLocation;
import org.jetbrains.annotations.Nullable;
import software.bernie.geckolib.renderer.GeoEntityRenderer;

public class MeteorRenderer extends GeoEntityRenderer<MeteorEntity> {

    public MeteorRenderer(EntityRendererProvider.Context context) {
        super(context, new MeteorModel());
    }

    @Override
    public ResourceLocation getTextureLocation(MeteorEntity animatable) {
        return ResourceLocation.fromNamespaceAndPath(Aac.MOD_ID, "textures/entity/meteor.png");
    }

    @Override
    public @Nullable RenderType getRenderType(MeteorEntity animatable, ResourceLocation texture,
                                               @Nullable MultiBufferSource bufferSource, float partialTick) {
        return RenderType.entityCutoutNoCull(texture);
    }
}
