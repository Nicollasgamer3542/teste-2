package com.brpacks.arkanis.aac.custom.command;

import com.brpacks.arkanis.aac.custom.entity.meteor.MeteorEntity;
import com.brpacks.arkanis.aac.registry.ModEntities;
import com.mojang.brigadier.arguments.IntegerArgumentType;
import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import net.minecraft.commands.CommandBuildContext;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.commands.arguments.coordinates.Vec3Argument;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.phys.Vec3;

public class SummonMeteor extends BaseCommand {

    public SummonMeteor() {
        super("summonmeteor", 2);
    }

    @Override
    protected void build(LiteralArgumentBuilder<CommandSourceStack> cmd, CommandBuildContext context) {
        cmd.then(Commands.argument("pos", Vec3Argument.vec3())
                .then(Commands.argument("height", IntegerArgumentType.integer(10, 300))
                        .executes(ctx -> {
                            Vec3 pos = Vec3Argument.getVec3(ctx, "pos");
                            int height = IntegerArgumentType.getInteger(ctx, "height");
                            return summonMeteor(ctx.getSource(), pos, height);
                        }))
                .executes(ctx -> {
                    Vec3 pos = Vec3Argument.getVec3(ctx, "pos");
                    return summonMeteor(ctx.getSource(), pos, 100);
                }));

        cmd.executes(ctx -> {
            Vec3 pos = ctx.getSource().getPosition();
            return summonMeteor(ctx.getSource(), pos, 100);
        });
    }

    private int summonMeteor(CommandSourceStack source, Vec3 targetPos, int height) {
        ServerLevel level = source.getLevel();
        MeteorEntity meteor = new MeteorEntity(ModEntities.METEOR_ENTITY.get(), level);
        meteor.setTarget(BlockPos.containing(targetPos));
        meteor.moveTo(targetPos.x, targetPos.y + height, targetPos.z);
        level.addFreshEntity(meteor);
        source.sendSuccess(() -> Component.literal("§aMeteoro invocado!"), true);
        return 1;
    }
}
