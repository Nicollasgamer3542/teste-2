package com.brpacks.arkanis.aac.custom.command;

import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import net.minecraft.commands.CommandBuildContext;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;

public abstract class BaseCommand implements ICommand {

    protected final String name;
    protected final int permissionLevel;

    protected BaseCommand(String name, int permissionLevel) {
        this.name = name;
        this.permissionLevel = permissionLevel;
    }

    @Override
    public void register(CommandDispatcher<CommandSourceStack> dispatcher, CommandBuildContext context) {
        LiteralArgumentBuilder<CommandSourceStack> command = Commands.literal(name)
                .requires(src -> src.hasPermission(permissionLevel));
        build(command, context);
        dispatcher.register(command);
    }

    protected abstract void build(LiteralArgumentBuilder<CommandSourceStack> cmd, CommandBuildContext context);
}
