package com.brpacks.arkanis.aac.event;

import com.brpacks.arkanis.aac.Aac;
import com.brpacks.arkanis.aac.Config;
import net.minecraft.network.chat.Component;
import net.minecraftforge.event.entity.player.PlayerEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

@Mod.EventBusSubscriber(modid = Aac.MOD_ID, bus = Mod.EventBusSubscriber.Bus.FORGE)
public class PlayerJoinServerEvent {

    @SubscribeEvent
    public static void onPlayerLogin(PlayerEvent.PlayerLoggedInEvent event) {
        if (!Config.ENABLE_JOIN_MESSAGE.get()) return;

        String raw = Config.JOIN_MESSAGE.get();
        String formatted = raw.replace("&", "§");
        event.getEntity().sendSystemMessage(Component.literal(formatted));
    }
}
