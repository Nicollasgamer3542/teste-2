package com.brpacks.arkanis.aac.custom.command;

import com.brpacks.arkanis.aac.custom.entity.laser.LaserEntity;
import com.brpacks.arkanis.aac.custom.entity.laser.mode.LaserMode;
import com.brpacks.arkanis.aac.registry.ModEntities;
import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import net.minecraft.commands.CommandBuildContext;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.commands.arguments.EntityArgument;
import net.minecraft.commands.arguments.coordinates.Vec3Argument;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.phys.Vec3;

import java.util.Collection;

public class TeleportCommand extends BaseCommand {

    public TeleportCommand() {
        super("aacteleport", 2);
    }

    @Override
    protected void build(LiteralArgumentBuilder<CommandSourceStack> cmd, CommandBuildContext context) {
        cmd.then(Commands.argument("targets", EntityArgument.players())
                .then(Commands.argument("destination", Vec3Argument.vec3())
                        .executes(ctx -> {
                            Collection<ServerPlayer> players = EntityArgument.getPlayers(ctx, "targets");
                            Vec3 dest = Vec3Argument.getVec3(ctx, "destination");
                            ServerLevel level = ctx.getSource().getLevel();

                            for (ServerPlayer player : players) {
                                LaserEntity laser = new LaserEntity(ModEntities.LASER_ENTITY.get(), level);
                                laser.setMode(LaserMode.TELEPORT);
                                laser.setTargetPos(dest);
                                laser.setOwnerUUID(player.getUUID());
                                Vec3 start = player.position().add(0, 1, 0);
                                laser.moveTo(start.x, start.y, start.z);
                                level.addFreshEntity(laser);
                            }

                            ctx.getSource().sendSuccess(
                                    () -> Component.literal("§aTeleportando " + players.size() + " jogador(es)."), true);
                            return players.size();
                        })));
    }
}
